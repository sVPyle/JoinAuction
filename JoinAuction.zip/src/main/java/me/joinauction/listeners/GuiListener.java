package me.joinauction.listeners;

import me.joinauction.JoinAuction;
import me.joinauction.database.AuctionItem;
import me.joinauction.gui.JoinGui;
import me.joinauction.utils.ColorUtils;
import me.joinauction.utils.ItemNameManager;
import me.joinauction.utils.ItemSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import java.util.UUID;

public class GuiListener implements Listener {
    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof JoinGui)) return;
        e.setCancelled(true);

        Player buyer = (Player) e.getWhoClicked();
        if (e.getRawSlot() >= 45) return; // Клик по кнопкам управления

        // В реальной покупке мы берем данные из AuctionItem привязанного к слоту
        // Ниже пример логики уведомления продавца при покупке:
        handleNotifySeller(buyer, e.getCurrentItem(), 100.0, UUID.randomUUID());
    }

    private void handleNotifySeller(Player buyer, ItemStack item, double finalPrice, UUID sellerUUID) {
        Player seller = Bukkit.getPlayer(sellerUUID);
        String itemName = ItemNameManager.getDisplayName(item);

        if (seller != null && seller.isOnline()) {
            JoinAuction.getInstance().getFiles().getLang().getStringList("messages.item-sold-online").forEach(line ->
                    seller.sendMessage(ColorUtils.format(line
                            .replace("%name-id-item%", itemName)
                            .replace("%price-item%", String.valueOf(finalPrice)))));
        } else {
            // Если оффлайн - Database.java запишет это в таблицу ah_payments автоматически
            JoinAuction.getInstance().getDB().addOfflinePayment(sellerUUID, finalPrice);
        }
    }
}
