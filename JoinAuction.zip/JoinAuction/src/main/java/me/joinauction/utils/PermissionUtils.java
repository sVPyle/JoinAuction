package me.joinauction.utils;

import org.bukkit.entity.Player;
import org.bukkit.permissions.PermissionAttachmentInfo;

public class PermissionUtils {
    public static boolean canSell(Player p, boolean direct) {
        String base = direct ? "auction.slot.dsell." : "auction.slot.sell.";
        return p.getEffectivePermissions().stream().anyMatch(pa -> pa.getPermission().startsWith(base));
    }
    public static int getMaxSlots(Player p, String base) {
        return p.getEffectivePermissions().stream()
                .filter(pa -> pa.getPermission().startsWith(base))
                .map(pa -> Integer.parseInt(pa.getPermission().replace(base, "")))
                .max(Integer::compare).orElse(0);
    }
}
