package me.joinauction.utils;

import net.md_5.bungee.api.ChatColor;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ColorUtils {
    private static final Pattern HEX = Pattern.compile("&\\{#([A-Fa-f0-9]{6})}");
    public static String format(String msg) {
        Matcher m = HEX.matcher(msg);
        while (m.find()) msg = msg.replace(m.group(), ChatColor.of("#" + m.group(1)).toString());
        return ChatColor.translateAlternateColorCodes('&', msg);
    }
    public static List<String> formatList(List<String> l) { return l.stream().map(ColorUtils::format).collect(Collectors.toList()); }
}
