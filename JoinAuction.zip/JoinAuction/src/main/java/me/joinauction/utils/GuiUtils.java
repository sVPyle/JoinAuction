package me.joinauction.utils;

import java.util.ArrayList;
import java.util.List;

public class GuiUtils {

    /**
     * Превращает список строк (["1", "10-12"]) в список Integer ([1, 10, 11, 12])
     */
    public static List<Integer> parseSlots(List<String> rawSlots) {
        List<Integer> slots = new ArrayList<>();
        if (rawSlots == null) return slots;

        for (String s : rawSlots) {
            try {
                if (s.contains("-")) {
                    String[] parts = s.split("-");
                    int start = Integer.parseInt(parts[0].trim());
                    int end = Integer.parseInt(parts[1].trim());
                    // Поддержка обратного порядка (на всякий случай)
                    int min = Math.min(start, end);
                    int max = Math.max(start, end);
                    for (int i = min; i <= max; i++) {
                        slots.add(i);
                    }
                } else {
                    slots.add(Integer.parseInt(s.trim()));
                }
            } catch (NumberFormatException e) {
                // Игнорируем некорректные записи в конфиге
            }
        }
        return slots;
    }
}
