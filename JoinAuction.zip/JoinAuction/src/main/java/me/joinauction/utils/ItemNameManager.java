package me.joinauction.utils;

import me.joinauction.JoinAuction;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;

public class ItemNameManager {
    public static String getDisplayName(ItemStack item) {
        if (item == null || item.getType().isAir()) return "Воздух";

        // 1. Приоритет: DisplayName из игры
        if (item.hasItemMeta() && item.getItemMeta().hasDisplayName()) {
            return item.getItemMeta().getDisplayName();
        }

        // 2. Поиск в item-settings из lang файла
        ConfigurationSection section = JoinAuction.getInstance().getFiles().getLang().getConfigurationSection("item-settings");
        if (section != null) {
            String materialName = item.getType().name();
            for (String key : section.getKeys(false)) {
                if (key.equalsIgnoreCase(materialName)) {
                    // Убираем приписку плагина ~[plugin:...]
                    return ColorUtils.format(section.getString(key).split(" ~")[0]);
                }
            }
        }

        // 3. Стандартное название
        return item.getType().name().toLowerCase().replace("_", " ");
    }
}
