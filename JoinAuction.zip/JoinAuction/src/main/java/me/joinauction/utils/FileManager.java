package me.joinauction.utils;

import me.joinauction.JoinAuction;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;

public class FileManager {
    private JoinAuction plugin;
    private FileConfiguration lang;

    public FileManager(JoinAuction p) { this.plugin = p; }
    public void init() {
        plugin.saveDefaultConfig();
        File lf = new File(plugin.getDataFolder(), "lang/ru_ru.yml");
        if (!lf.exists()) plugin.saveResource("lang/ru_ru.yml", false);
        lang = YamlConfiguration.loadConfiguration(lf);
    }
    public FileConfiguration getLang() { return lang; }
}
