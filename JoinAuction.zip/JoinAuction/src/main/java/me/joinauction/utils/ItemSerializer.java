package me.joinauction.utils;

import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;
import java.io.*;

public class ItemSerializer {
    public static String toBase64(ItemStack item) {
        try (ByteArrayOutputStream os = new ByteArrayOutputStream(); BukkitObjectOutputStream bos = new BukkitObjectOutputStream(os)) {
            bos.writeObject(item); return Base64Coder.encodeLines(os.toByteArray());
        } catch (Exception e) { return ""; }
    }
    public static ItemStack fromBase64(String data) {
        try (ByteArrayInputStream is = new ByteArrayInputStream(Base64Coder.decodeLines(data)); BukkitObjectInputStream bis = new BukkitObjectInputStream(is)) {
            return (ItemStack) bis.readObject();
        } catch (Exception e) { return null; }
    }
}
