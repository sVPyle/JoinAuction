package me.joinauction.utils;

import org.bukkit.inventory.ItemStack;

public class CategoryMatcher {
    public static String getCategory(ItemStack item) {
        String type = item.getType().name();
        if (type.contains("SWORD")) return "weapons";
        if (type.contains("BLOCK")) return "blocks";
        return "other";
    }
}
