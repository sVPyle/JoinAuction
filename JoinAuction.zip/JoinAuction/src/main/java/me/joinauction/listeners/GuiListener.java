package me.joinauction.listeners;

import me.joinauction.JoinAuction;
import me.joinauction.gui.*;
import me.joinauction.utils.ColorUtils;
import me.joinauction.utils.GuiUtils;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

import java.util.List;

public class GuiListener implements Listener {

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof JoinGui gui)) return;

        e.setCancelled(true);

        Player p = (Player) e.getWhoClicked();
        int clickedSlot = e.getRawSlot();
        FileConfiguration config = JoinAuction.getInstance().getConfig();

        // --- ЛОГИКА ГЛАВНОГО МЕНЮ ---
        if (gui instanceof AuctionMainGui) {
            if (isClicked(clickedSlot, config, "menus.main-menu.items.my_goods.slot")) {
                new StorageGui(p).open();
            } else if (isClicked(clickedSlot, config, "menus.main-menu.items.categories.slot")) {
                new CategoryGui(p).open();
            } else if (isClicked(clickedSlot, config, "menus.main-menu.items.update.slot")) {
                new AuctionMainGui(p, 0, null).open();
            } else if (isClicked(clickedSlot, config, "menus.main-menu.items.next.slot")) {
                // Логика следующей страницы (page + 1)
            } else if (isClicked(clickedSlot, config, "menus.main-menu.items.back.slot")) {
                // Логика предыдущей страницы
            }
            // Клик по самому товару (слоты под товары обычно 0-44)
            else if (clickedSlot >= 0 && clickedSlot <= 44 && e.getCurrentItem() != null) {
                // Открываем меню подтверждения
                // В реальной версии тут берем цену из AuctionItem
                new ConfirmGui(p, e.getCurrentItem(), 1000.0).open();
            }
        }

        // --- ЛОГИКА МЕНЮ ПОДТВЕРЖДЕНИЯ ---
        else if (gui instanceof ConfirmGui confirmGui) {
            if (isClicked(clickedSlot, config, "menus.confirm-menu.items.confirm.slot")) {
                handlePurchase(p, confirmGui);
            } else if (isClicked(clickedSlot, config, "menus.confirm-menu.items.cancel.slot")) {
                p.sendMessage(ColorUtils.format("&{#b50000}☃ &fПокупка отменена."));
                new AuctionMainGui(p, 0, null).open();
            }
        }
    }

    /**
     * Универсальная проверка: попал ли игрок в один из указанных слотов кнопки
     */
    private boolean isClicked(int slot, FileConfiguration config, String path) {
        List<String> raw = config.getStringList(path);
        // Если в конфиге просто число (не список), getStringList вернет пустой список,
        // поэтому пробуем считать как одиночную строку если список пуст
        if (raw.isEmpty() && config.contains(path)) {
            raw.add(config.getString(path));
        }
        return GuiUtils.parseSlots(raw).contains(slot);
    }

    private void handlePurchase(Player p, ConfirmGui gui) {
        double price = gui.getPrice();
        if (JoinAuction.getEconomy().has(p, price)) {
            JoinAuction.getEconomy().withdrawPlayer(p, price);
            p.getInventory().addItem(gui.getItemToBuy());
            p.sendMessage(ColorUtils.format("&{#b50000}☃ &fВы успешно купили товар за &a" + price + "$"));
            p.closeInventory();
        } else {
            p.sendMessage(ColorUtils.format("&{#b50000}☃ &cНедостаточно средств!"));
            p.closeInventory();
        }
    }
}
