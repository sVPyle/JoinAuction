package me.joinauction.listeners;

import me.joinauction.JoinAuction;
import me.joinauction.utils.ColorUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class JoinListener implements Listener {
    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player player = e.getPlayer();

        JoinAuction.getInstance().getDB().getOfflineStats(player.getUniqueId()).thenAccept(stats -> {
            if (stats != null && stats.getAmount() > 0) {
                // Начисляем деньги
                JoinAuction.getEconomy().depositPlayer(player, stats.getAmount());

                // Отправляем сводку из lang
                JoinAuction.getInstance().getFiles().getLang().getStringList("messages.item-sold-offline-summary").forEach(line ->
                        player.sendMessage(ColorUtils.format(line
                                .replace("%amount%", String.valueOf(stats.getAmount()))
                                .replace("%count%", String.valueOf(stats.getCount())))));

                // Очищаем запись в БД
                JoinAuction.getInstance().getDB().clearOfflineStats(player.getUniqueId());
            }
        });
    }
}
