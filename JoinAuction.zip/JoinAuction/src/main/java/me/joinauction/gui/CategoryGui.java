package me.joinauction.gui;

import me.joinauction.JoinAuction;
import me.joinauction.utils.ColorUtils;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class CategoryGui extends JoinGui {
    public CategoryGui(Player p) { super(p, 45, "&{#b50000}☃&c&l Выбор категории"); }

    @Override
    public void setupItems() {
        ConfigurationSection sec = JoinAuction.getInstance().getConfig().getConfigurationSection("menu.categories-menu.items");
        for (String key : sec.getKeys(false)) {
            ItemStack it = new ItemStack(Material.valueOf(sec.getString(key + ".material")));
            ItemMeta m = it.getItemMeta();
            m.setDisplayName(ColorUtils.format(sec.getString(key + ".name")));
            it.setItemMeta(m);
            inv.setItem(sec.getInt(key + ".slot"), it);
        }
    }
}
