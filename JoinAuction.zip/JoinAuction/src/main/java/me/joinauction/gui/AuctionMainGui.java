package me.joinauction.gui;

import me.joinauction.JoinAuction;
import me.joinauction.utils.ColorUtils;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import java.util.UUID;

public class AuctionMainGui extends JoinGui {
    private String query;
    private UUID target;

    public AuctionMainGui(Player p, int page, String cat) {
        super(p, 54, JoinAuction.getInstance().getConfig().getString("menus.main-menu.name"));
    }

    @Override
    public void setupItems() {
        setBtn(47, "my_goods");
        setBtn(49, "back");
        setBtn(50, "update");
        setBtn(51, "next");
        setBtn(53, "categories");
    }

    private void setBtn(int slot, String key) {
        String path = "menus.main-menu.items." + key;
        ItemStack item = new ItemStack(Material.valueOf(JoinAuction.getInstance().getConfig().getString(path + ".material")));
        ItemMeta m = item.getItemMeta();
        m.setDisplayName(ColorUtils.format(JoinAuction.getInstance().getConfig().getString(path + ".name")));
        m.setLore(ColorUtils.formatList(JoinAuction.getInstance().getConfig().getStringList(path + ".lore")));
        item.setItemMeta(m);
        inv.setItem(slot, item);
    }

    public AuctionMainGui setSearchQuery(String q) { this.query = q; return this; }
    public AuctionMainGui setTargetSeller(UUID id) { this.target = id; return this; }
}
