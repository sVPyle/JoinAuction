package me.joinauction.gui;

import me.joinauction.utils.ColorUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public abstract class JoinGui implements InventoryHolder {
    protected final Inventory inv;
    protected final Player player;

    public JoinGui(Player player, int size, String title) {
        this.player = player;
        this.inv = Bukkit.createInventory(this, size, ColorUtils.format(title));
    }

    public abstract void setupItems();
    public void open() { setupItems(); player.openInventory(inv); }
    @Override public Inventory getInventory() { return inv; }
}
