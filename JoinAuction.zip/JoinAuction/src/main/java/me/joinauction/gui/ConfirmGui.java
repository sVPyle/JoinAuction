package me.joinauction.gui;

import me.joinauction.JoinAuction;
import me.joinauction.utils.ColorUtils;
import me.joinauction.utils.GuiUtils;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class ConfirmGui extends JoinGui {
    private final ItemStack itemToBuy;
    private final double price;

    public ConfirmGui(Player player, ItemStack item, double price) {
        super(player,
                JoinAuction.getInstance().getConfig().getInt("menus.confirm-menu.size", 27),
                JoinAuction.getInstance().getConfig().getString("menus.confirm-menu.name", "&{#b50000}✔ Подтверждение")
        );
        this.itemToBuy = item;
        this.price = price;
    }

    @Override
    public void setupItems() {
        FileConfiguration config = JoinAuction.getInstance().getConfig();
        inv.clear();

        // Данные экономики для плейсхолдеров
        double balance = JoinAuction.getEconomy().getBalance(player);
        double remain = balance - price;

        // 1. Кнопки Подтверждения
        ItemStack confirmBtn = createConfigItem(config, "menus.confirm-menu.items.confirm", balance, remain);
        applySlots(config.getStringList("menus.confirm-menu.items.confirm.slot"), confirmBtn);

        // 2. Кнопки Отмены
        ItemStack cancelBtn = createConfigItem(config, "menus.confirm-menu.items.cancel", balance, remain);
        applySlots(config.getStringList("menus.confirm-menu.items.cancel.slot"), cancelBtn);

        // 3. Предмет покупки (Центральное превью)
        setupPreviewItem(config, balance, remain);

        // 4. Заполнитель (Filler)
        setupFiller(config);

        // Эффект при открытии (Звук перелистывания страниц или тихий клик)
        player.playSound(player.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.2f);
    }

    private void setupPreviewItem(FileConfiguration config, double balance, double remain) {
        ItemStack preview = itemToBuy.clone();
        ItemMeta meta = preview.getItemMeta();

        if (meta != null) {
            // Добавляем инфо о сделке в Лор самого предмета (временно для GUI)
            List<String> lore = meta.hasLore() ? meta.getLore() : new ArrayList<>();
            lore.add(" ");
            lore.add(ColorUtils.format("&8&m-------&r &6ИНФОРМАЦИЯ &8&m-------"));
            lore.add(ColorUtils.format("&fЦена: &a" + price + "$"));
            lore.add(ColorUtils.format("&fВаш баланс: &7" + balance + "$"));
            lore.add(ColorUtils.format("&fОстаток: &e" + (remain < 0 ? "&c" : "&a") + remain + "$"));
            meta.setLore(lore);

            // Эффект свечения для центрального предмета
            if (config.getBoolean("menus.confirm-menu.items.buy-item-preview.glow", true)) {
                meta.addEnchant(Enchantment.SHARPNESS, 1, true);
                meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }
            preview.setItemMeta(meta);
        }

        int slot = config.getInt("menus.confirm-menu.items.buy-item-preview.slot", 13);
        inv.setItem(slot, preview);
    }

    private ItemStack createConfigItem(FileConfiguration config, String path, double balance, double remain) {
        Material mat = Material.valueOf(config.getString(path + ".material", "BARRIER"));
        ItemStack is = new ItemStack(mat);
        ItemMeta m = is.getItemMeta();

        if (m != null) {
            m.setDisplayName(ColorUtils.format(config.getString(path + ".name", " ")));

            // Обработка кастомных плейсхолдеров в Lore кнопок
            List<String> lore = new ArrayList<>();
            for (String line : config.getStringList(path + ".lore")) {
                lore.add(ColorUtils.format(line
                        .replace("%price%", String.valueOf(price))
                        .replace("%balance%", String.valueOf(balance))
                        .replace("%remain%", String.valueOf(remain))
                ));
            }
            m.setLore(lore);

            // Свечение (Glow)
            if (config.getBoolean(path + ".glow", false)) {
                m.addEnchant(Enchantment.SHARPNESS, 1, true);
                m.addItemFlags(ItemFlag.HIDE_ENCHANTS);
            }

            is.setItemMeta(m);
        }
        return is;
    }

    private void applySlots(List<String> rawSlots, ItemStack item) {
        for (int slot : GuiUtils.parseSlots(rawSlots)) {
            if (slot >= 0 && slot < inv.getSize()) inv.setItem(slot, item);
        }
    }

    private void setupFiller(FileConfiguration config) {
        if (config.contains("menus.confirm-menu.filler")) {
            Material mat = Material.valueOf(config.getString("menus.confirm-menu.filler.material", "AIR"));
            if (mat == Material.AIR) return;

            ItemStack filler = new ItemStack(mat);
            ItemMeta fMeta = filler.getItemMeta();
            fMeta.setDisplayName(ColorUtils.format(config.getString("menus.confirm-menu.filler.name", " ")));
            filler.setItemMeta(fMeta);

            List<Integer> slots = GuiUtils.parseSlots(config.getStringList("menus.confirm-menu.filler.slots"));
            for (int s : slots) {
                if (s >= 0 && s < inv.getSize() && inv.getItem(s) == null) inv.setItem(s, filler);
            }
        }
    }

    public double getPrice() { return price; }
    public ItemStack getItemToBuy() { return itemToBuy; }
}
