package me.joinauction.gui;

import org.bukkit.entity.Player;

public class StorageGui extends JoinGui {
    public StorageGui(Player p) { super(p, 54, "&{#b50000}[☃] &cХранилище"); }
    @Override public void setupItems() { /* Логика загрузки личных вещей из БД */ }
}
