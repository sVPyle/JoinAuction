package me.joinauction.database;

import me.joinauction.utils.ItemSerializer;
import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class AuctionItem {

    private final int id;
    private final UUID sellerUUID;
    private final String sellerName;
    private final String base64Data;
    private final double price;
    private final long expiryTime;
    private final boolean isDirect;
    private ItemStack cachedStack;

    /**
     * Конструктор для создания объекта из данных БД
     */
    public AuctionItem(int id, UUID sellerUUID, String base64Data, double price, long expiryTime, boolean isDirect) {
        this.id = id;
        this.sellerUUID = sellerUUID;
        // Пытаемся получить имя игрока, если он в сети, иначе используем UUID или "Продавец"
        this.sellerName = Bukkit.getOfflinePlayer(sellerUUID).getName() != null ?
                Bukkit.getOfflinePlayer(sellerUUID).getName() : "Неизвестен";
        this.base64Data = base64Data;
        this.price = price;
        this.expiryTime = expiryTime;
        this.isDirect = isDirect;
    }

    /**
     * Возвращает ItemStack. Использует кэширование, чтобы не
     * десериализовать Base64 каждый раз при обновлении GUI.
     */
    public ItemStack getItemStack() {
        if (cachedStack == null) {
            cachedStack = ItemSerializer.fromBase64(base64Data);
        }
        return cachedStack != null ? cachedStack.clone() : null;
    }

    public int getId() {
        return id;
    }

    public UUID getSellerUUID() {
        return sellerUUID;
    }

    public String getSellerName() {
        return sellerName;
    }

    public String getBase64Data() {
        return base64Data;
    }

    public double getPrice() {
        return price;
    }

    public long getExpiryTime() {
        return expiryTime;
    }

    public boolean isDirect() {
        return isDirect;
    }

    /**
     * Рассчитывает оставшееся время в человекочитаемом формате
     * Например: "2ч. 15м."
     */
    public String getRemainingTime() {
        long remaining = expiryTime - System.currentTimeMillis();
        if (remaining <= 0) return "Истекло";

        long hours = remaining / (1000 * 60 * 60);
        long minutes = (remaining / (1000 * 60)) % 60;

        if (hours > 0) {
            return String.format("%dч. %dм.", hours, minutes);
        } else {
            return String.format("%dм.", minutes);
        }
    }
}
