package me.joinauction.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import me.joinauction.JoinAuction;
import me.joinauction.utils.ItemSerializer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.sql.*;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class Database {
    private HikariDataSource dataSource;

    public void connect() {
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl("jdbc:sqlite:" + JoinAuction.getInstance().getDataFolder() + "/auction.db");
        config.setPoolName("JoinAuctionPool");
        config.setMaximumPoolSize(10);
        this.dataSource = new HikariDataSource(config);

        setupTables();
    }

    private void setupTables() {
        try (Connection c = dataSource.getConnection(); Statement s = c.createStatement()) {
            s.execute("CREATE TABLE IF NOT EXISTS ah_items (id INTEGER PRIMARY KEY AUTOINCREMENT, seller VARCHAR(36), data TEXT, price DOUBLE, direct BOOLEAN)");
            s.execute("CREATE TABLE IF NOT EXISTS ah_payments (uuid VARCHAR(36), amount DOUBLE)");
        } catch (SQLException e) { e.printStackTrace(); }
    }

    public void listItem(Player p, ItemStack item, double price, boolean direct) {
        CompletableFuture.runAsync(() -> {
            try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement("INSERT INTO ah_items (seller, data, price, direct) VALUES (?, ?, ?, ?)")) {
                ps.setString(1, p.getUniqueId().toString());
                ps.setString(2, ItemSerializer.toBase64(item));
                ps.setDouble(3, price);
                ps.setBoolean(4, direct);
                ps.executeUpdate();
            } catch (SQLException e) { e.printStackTrace(); }
        });
    }

    public void addOfflinePayment(UUID uuid, double amount) {
        CompletableFuture.runAsync(() -> {
            try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement("INSERT INTO ah_payments (uuid, amount) VALUES (?, ?)")) {
                ps.setString(1, uuid.toString());
                ps.setDouble(2, amount);
                ps.executeUpdate();
            } catch (SQLException e) { e.printStackTrace(); }
        });
    }

    public CompletableFuture<OfflineStats> getOfflineStats(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement("SELECT SUM(amount), COUNT(*) FROM ah_payments WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ResultSet rs = ps.executeQuery();
                if (rs.next() && rs.getDouble(1) > 0) {
                    return new OfflineStats(rs.getDouble(1), rs.getInt(2));
                }
            } catch (SQLException e) { e.printStackTrace(); }
            return null;
        });
    }

    public void clearOfflineStats(UUID uuid) {
        CompletableFuture.runAsync(() -> {
            try (Connection c = dataSource.getConnection(); PreparedStatement ps = c.prepareStatement("DELETE FROM ah_payments WHERE uuid = ?")) {
                ps.setString(1, uuid.toString());
                ps.executeUpdate();
            } catch (SQLException e) { e.printStackTrace(); }
        });
    }

    public static class OfflineStats {
        private final double amount;
        private final int count;
        public OfflineStats(double a, int c) { this.amount = a; this.count = c; }
        public double getAmount() { return amount; }
        public int getCount() { return count; }
    }
}
