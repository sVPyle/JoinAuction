package me.joinauction;

import me.joinauction.commands.AhCommand;
import me.joinauction.database.Database;
import me.joinauction.listeners.GuiListener;
import me.joinauction.listeners.JoinListener;
import me.joinauction.utils.FileManager;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public class JoinAuction extends JavaPlugin {
    private static JoinAuction instance;
    private static Economy econ = null;
    private Database database;
    private FileManager fileManager;

    @Override
    public void onEnable() {
        instance = this;
        this.fileManager = new FileManager(this);
        this.fileManager.init();

        if (!setupEconomy()) {
            getLogger().severe("Vault не найден! Плагин выключен.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        this.database = new Database();
        this.database.connect();

        getCommand("ah").setExecutor(new AhCommand());
        getCommand("ja").setExecutor(new AhCommand());
        getServer().getPluginManager().registerEvents(new GuiListener(), this);
        getServer().getPluginManager().registerEvents(new JoinListener(), this);
    }

    private boolean setupEconomy() {
        if (getServer().getPluginManager().getPlugin("Vault") == null) return false;
        RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
        if (rsp == null) return false;
        econ = rsp.getProvider();
        return econ != null;
    }

    public static JoinAuction getInstance() { return instance; }
    public static Economy getEconomy() { return econ; }
    public Database getDB() { return database; }
    public FileManager getFiles() { return fileManager; }
}
