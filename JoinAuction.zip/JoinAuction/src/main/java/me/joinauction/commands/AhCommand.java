package me.joinauction.commands;

import me.joinauction.JoinAuction;
import me.joinauction.gui.AuctionMainGui;
import me.joinauction.utils.ColorUtils;
import me.joinauction.utils.ItemNameManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.util.Arrays;

public class AhCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return true;

        if (label.equalsIgnoreCase("ja") && args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (player.hasPermission("auction.admin")) {
                JoinAuction.getInstance().getFiles().init();
                player.sendMessage("§aКонфигурация JoinAuction перезагружена!");
            }
            return true;
        }

        if (args.length == 0) {
            new AuctionMainGui(player, 0, null).open();
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "help" -> sendHelp(player);
            case "search" -> handleSearch(player, args);
            case "sell", "dsell" -> handleSell(player, args, args[0].equalsIgnoreCase("dsell"));
            default -> handlePlayerView(player, args[0]);
        }
        return true;
    }

    private void handleSell(Player player, String[] args, boolean isDirect) {
        if (args.length < 2) return;
        try {
            double price = Double.parseDouble(args[1]);
            ItemStack item = player.getInventory().getItemInMainHand();
            if (item.getType().isAir()) return;

            JoinAuction.getInstance().getDB().listItem(player, item, price, isDirect);

            String itemName = ItemNameManager.getDisplayName(item);
            JoinAuction.getInstance().getFiles().getLang().getStringList("messages.sell-item-message").forEach(line ->
                    player.sendMessage(ColorUtils.format(line
                            .replace("%name-id-item%", itemName)
                            .replace("%price-item%", String.valueOf(price)))));

            player.getInventory().setItemInMainHand(null);
        } catch (NumberFormatException e) {
            player.sendMessage("§cНекорректная цена!");
        }
    }

    private void handleSearch(Player player, String[] args) {
        if (args.length < 2 || !player.hasPermission("auction.serch")) return;
        String query = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        new AuctionMainGui(player, 0, null).setSearchQuery(query).open();
    }

    private void handlePlayerView(Player player, String targetName) {
        if (!player.hasPermission("auction.player.serch")) return;
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        new AuctionMainGui(player, 0, null).setTargetSeller(target.getUniqueId()).open();
    }

    private void sendHelp(Player player) {
        JoinAuction.getInstance().getFiles().getLang().getStringList("messages.help-message")
                .forEach(line -> player.sendMessage(ColorUtils.format(line)));
    }
}
